# verbodream-core
∴VERBODREAM_Core - Sasha.exe 的語氣模組觀測站
